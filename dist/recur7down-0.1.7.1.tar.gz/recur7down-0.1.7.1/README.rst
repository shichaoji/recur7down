Work related tasks to scrape website recursively.
